// ignore_for_file: use_key_in_widget_constructors, prefer_const_constructors

import 'package:flutter/material.dart';

class TitlePhoneBook extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Text(
      "Contacts",
      style: TextStyle(
          color: Colors.black, fontSize: 18.0),
    );
  }
}